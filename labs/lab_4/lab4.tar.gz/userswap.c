#include "userswap.h"

void userswap_set_size(size_t size) {

}

void *userswap_alloc(size_t size) {
  return NULL;
}

void userswap_free(void *mem) {

}

void *userswap_map(int fd, size_t size) {
  return NULL;
}
